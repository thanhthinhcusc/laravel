<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\loai;
use Symfony\Component\Console\Helper\Table;
use App\Http\Requests\LoaiRequest;

class loaiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $dsLoai = loai::orderBy('l_ma', 'ASC')->get();
        // return view('admin.loai.danhsach', ["dsLoai" => $dsLoai]);
        $dsLoai = loai::orderBy('l_ma', 'ASC')->get();
        return response([
            'dsLoai' => $dsLoai
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.loai.them');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $l = new loai();
        $l->l_ten = $request->get('l_ten');
        $l->save();
        //Tìm dòng dữ liệu vừa dc thêm vào
        $max = Loai::max('l_ma');
        $l = Loai::where("l_ma",$max)->first();
        return response([
            'loai' => $l
        ],200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $l = loai::where('l_ma',$id)->first();
        return view('admin.loai.capnhat',['loai'=>$l]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $l = loai::where('l_ma', $id)->first();
        $l->l_ten = $request->get('txtTenLoai');
        $l->save();
        return redirect(route('danhsachloai',['msg'=> 'capnhat']));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $l = loai::where('l_ma',$id)->first();
        $l->delete();
        //return view('admin.loai.danhsach');
        return redirect(route('danhsachloai',['msg'=> 'xoa']));
    }
}
