<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Nhanvien;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class authController extends Controller
{
    public function dangnhap(Request $request){
        $us = $request->get('username');
        $pw = $request->get('pass');


        $nv = DB::table('Nhanvien')->where('nv_taiKhoan',$us)->where('nv_matKhau',md5($pw))->count();
        //dd($nv);
        if($nv > 0){
            Session::put('us', $us);
            return redirect(route('danhsachloai'));
        }
        return redirect(route('dangnhapadmin'));
    }
}
